public class Test {
    public static void main(String[] args) {
        Sword<Steel> steelSword = new Sword<>(new Steel());
        System.out.println("Проверка на прочность: " + steelSword.isStrongEnough());
        //Меч из пластика создать не получится, появляется ошибка
        //Sword<Plastic> plasticSword = new Sword<>(new Plastic());

    }
}