class Steel extends Metal {
    @Override
    public int getEndurance() {
        return 50;
    }
}
