
class Sword<M extends Metal> {
    private M material;
    public Sword(M material) {
        this.material = material;
    }
    public boolean isStrongEnough() {
        return material.getEndurance() > 49;
    }
}


