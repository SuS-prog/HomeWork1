class Copper extends Metal {
    @Override
    public int getEndurance() {
        return 20;
    }
}

