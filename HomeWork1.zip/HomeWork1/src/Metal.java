abstract class Metal {
    public abstract int getEndurance();
}
